#!/bin/bash

# Set variables

source_dir="/path/to/source/directory"
destination_dir="/path/to/destination/directory" 


# Check if source directory exists

if [ ! -d "$source_dir" ]; then
  echo "Error: Source directory '$source_dir' does not exist."
  exit 1
fi

# Create backup directory
backup_dir="$destination_dir/backup_$(date +%Y%m%d_%H%M%S)"
mkdir -p "$backup_dir"

# Perform backup (using rsync for example)

rsync -avz "$source_dir/" "$backup_dir/"

# Check for backup success

if [ $? -eq 0 ]; then
  echo "Backup successful. Files copied to '$backup_dir'"
else
  echo "Backup failed."
fi