#!/bin/bash

# Define thresholds

CPU_THRESHOLD=80
MEMORY_THRESHOLD=80
DISK_SPACE_THRESHOLD=90

# Check CPU usage

cpu_usage=$(top -bn1 | grep "Cpu(s):" | awk '{print $2+$4}')
if [[ $(echo "$cpu_usage > $CPU_THRESHOLD" | bc) -eq 1 ]]; then
  echo "WARNING: CPU usage is high: $cpu_usage%"
fi

# Check memory usage

mem_usage=$(free -m | awk '/Mem:/ {print $3/$2 * 100.0}')
if [[ $(echo "$mem_usage > $MEMORY_THRESHOLD" | bc) -eq 1 ]]; then
  echo "WARNING: Memory usage is high: $mem_usage%"
fi

# Check disk space usage

disk_usage=$(df -h / | awk '$NF=="/"{printf "%.0f", $5}' | cut -d'%' -f1)
if [[ $(echo "$disk_usage > $DISK_SPACE_THRESHOLD" | bc) -eq 1 ]]; then
  echo "WARNING: Disk space usage is high: $disk_usage%"
fi

# Check number of running processes

num_processes=$(ps aux | wc -l)
echo "Number of running processes: $num_processes" 

# Log the results :

echo "CPU Usage: $cpu_usage%" >> system_health.log
echo "Memory Usage: $mem_usage%" >> system_health.log
echo "Disk Space Usage: $disk_usage%" >> system_health.log
echo "Number of Processes: $num_processes" >> system_health.log
